#!/bin/sh

python3 ./main.py -s FrameSimple